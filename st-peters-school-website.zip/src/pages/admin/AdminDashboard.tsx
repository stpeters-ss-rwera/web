import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaTachometerAlt, FaUsers, FaImages, FaNewspaper, FaBullhorn,
  FaCog, FaSignOutAlt, FaBars, FaTimes, FaSchool, FaCamera,
  FaTrash, FaEdit, FaPlus, FaUpload,
  FaStar, FaChartBar, FaLink, FaExternalLinkAlt, FaCheck, FaUser
} from 'react-icons/fa';
import { supabase, uploadImage, BUCKETS } from '../../lib/supabase';
import { SCHOOL_INFO, SAMPLE_TEACHERS, SAMPLE_PREFECTS, SAMPLE_GALLERY, SAMPLE_ARTICLES, SAMPLE_ANNOUNCEMENTS } from '../../lib/constants';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { useDropzone } from 'react-dropzone';

// Type definitions
type Teacher = { id: string; name: string; position: string; photo_url: string; bio: string };
type Prefect = { id: string; name: string; position: string; photo_url: string };
type GalleryItem = { id: string; title: string; image_url: string; category: string; created_at: string };
type Article = { id: string; title: string; content: string; featured_image: string; author: string; category: string; tags: string[]; created_at: string };
type Announcement = { id: string; title: string; content: string; created_at: string };

type AdminSection = 'dashboard' | 'logo' | 'hero' | 'teachers' | 'prefects' | 'gallery' | 'articles' | 'announcements' | 'settings';

// Image Upload Drop Zone Component
const ImageDropZone: React.FC<{
  onUpload: (file: File) => void;
  preview?: string;
  loading?: boolean;
  label?: string;
}> = ({ onUpload, preview, loading, label = 'Click or drag image here' }) => {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { 'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.webp'] },
    maxFiles: 1,
    onDrop: (files) => files[0] && onUpload(files[0]),
  });

  return (
    <div>
      <div {...getRootProps()} className={`upload-zone ${isDragActive ? 'dragover' : ''} ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
        <input {...getInputProps()} />
        {preview ? (
          <div className="flex flex-col items-center gap-2">
            <img src={preview} alt="Preview" className="w-32 h-32 object-cover rounded-lg shadow-md" />
            <p className="text-sm text-gray-500">Click or drag to replace image</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 text-gray-400">
            <FaUpload size={32} className={isDragActive ? 'text-blue-500 animate-bounce' : ''} />
            <div>
              <p className="font-semibold text-gray-600">{isDragActive ? 'Drop image here!' : label}</p>
              <p className="text-xs mt-1">PNG, JPG, GIF up to 10MB</p>
            </div>
          </div>
        )}
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/80 rounded-xl">
            <div className="w-8 h-8 border-3 border-blue-900/30 border-t-blue-900 rounded-full animate-spin" />
          </div>
        )}
      </div>
    </div>
  );
};

// Modal component
const Modal: React.FC<{ title: string; onClose: () => void; children: React.ReactNode }> = ({ title, onClose, children }) => (
  <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center p-4 overflow-y-auto">
    <div className="bg-white rounded-2xl w-full max-w-lg my-8 shadow-2xl animate-scale-in">
      <div className="flex items-center justify-between p-5 border-b">
        <h3 className="font-bold text-blue-900 text-lg" style={{ fontFamily: 'Playfair Display, serif' }}>{title}</h3>
        <button onClick={onClose} className="w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors">
          <FaTimes size={14} />
        </button>
      </div>
      <div className="p-5">{children}</div>
    </div>
  </div>
);

// Sidebar Item
const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; section: AdminSection; active: AdminSection; onClick: (s: AdminSection) => void }> =
  ({ icon, label, section, active, onClick }) => (
    <button onClick={() => onClick(section)}
      className={`admin-sidebar-link w-full text-left ${active === section ? 'active' : ''}`}>
      <span className="w-5 flex-shrink-0">{icon}</span>
      <span className="text-sm">{label}</span>
    </button>
  );

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<AdminSection>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // State for different sections
  const [teachers, setTeachers] = useState<Teacher[]>(SAMPLE_TEACHERS);
  const [prefects, setPrefects] = useState<Prefect[]>(SAMPLE_PREFECTS);
  const [gallery, setGallery] = useState<GalleryItem[]>(SAMPLE_GALLERY);
  const [articles, setArticles] = useState<Article[]>(SAMPLE_ARTICLES);
  const [announcements, setAnnouncements] = useState<Announcement[]>(SAMPLE_ANNOUNCEMENTS);
  const [logoUrl, setLogoUrl] = useState('/logo.png');
  const [logoInput, setLogoInput] = useState('');

  // Modal states
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('');
  const [editItem, setEditItem] = useState<Record<string, unknown> | null>(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState('');
  const [uploadedImageUrl, setUploadedImageUrl] = useState('');

  // Form states
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [galleryCategory, setGalleryCategory] = useState('Events');
  const [galleryTitle, setGalleryTitle] = useState('');
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [_multipleFiles, setMultipleFiles] = useState<File[]>([]);
  const [learningLink, setLearningLink] = useState(SCHOOL_INFO.onlineLearningUrl);
  const [settingsForm, setSettingsForm] = useState({
    school_name: SCHOOL_INFO.name,
    email: SCHOOL_INFO.email,
    phone: SCHOOL_INFO.headTeacherPhone,
    whatsapp: SCHOOL_INFO.whatsappContact,
    location: SCHOOL_INFO.location,
    learning_link: SCHOOL_INFO.onlineLearningUrl,
  });

  // Check auth
  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const demoAuth = localStorage.getItem('admin_demo_auth');
      if (!session && !demoAuth) {
        navigate('/admin');
      }
    };
    checkAuth();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('admin_demo_auth');
    toast.success('Logged out successfully.');
    navigate('/admin');
  };

  const openModal = (type: string, item?: Record<string, unknown>) => {
    setModalType(type);
    setEditItem(item || null);
    setImagePreview(item?.photo_url as string || item?.image_url as string || item?.featured_image as string || '');
    setUploadedImageUrl('');
    setFormData({
      name: item?.name as string || '',
      position: item?.position as string || '',
      bio: item?.bio as string || '',
      title: item?.title as string || '',
      content: item?.content as string || '',
      author: item?.author as string || '',
      category: item?.category as string || '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditItem(null);
    setImagePreview('');
    setUploadedImageUrl('');
    setMultipleFiles([]);
    setGalleryTitle('');
  };

  const handleImageUpload = async (file: File, folder: string = 'uploads') => {
    setUploadLoading(true);
    setImagePreview(URL.createObjectURL(file));
    const result = await uploadImage(BUCKETS.SCHOOL_IMAGES, file, folder);
    setUploadLoading(false);
    if (result) {
      setUploadedImageUrl(result.url);
      toast.success('Image uploaded successfully!');
    } else {
      // Fallback for demo
      const fakeUrl = URL.createObjectURL(file);
      setUploadedImageUrl(fakeUrl);
      toast.success('Image preview ready! (Connect Supabase for permanent storage)');
    }
    return result?.url || URL.createObjectURL(file);
  };

  const handleLogoUpload = async (file: File) => {
    setUploadLoading(true);
    const preview = URL.createObjectURL(file);
    setLogoUrl(preview);
    const result = await uploadImage(BUCKETS.SCHOOL_LOGO, file, 'logo');
    setUploadLoading(false);
    if (result) {
      setLogoUrl(result.url);
      toast.success('Logo updated successfully!');
    } else {
      toast.success('Logo preview ready! (Connect Supabase for permanent storage)');
    }
  };

  const handleSaveTeacher = () => {
    const photoUrl = uploadedImageUrl || editItem?.photo_url as string || '';
    if (editItem) {
      setTeachers(prev => prev.map(t => t.id === editItem.id ? { ...t, ...formData, photo_url: photoUrl } : t));
      toast.success('Teacher updated!');
    } else {
      const newTeacher: Teacher = { id: Date.now().toString(), name: formData.name, position: formData.position, bio: formData.bio, photo_url: photoUrl };
      setTeachers(prev => [...prev, newTeacher]);
      toast.success('Teacher added!');
    }
    closeModal();
  };

  const handleSavePrefect = () => {
    const photoUrl = uploadedImageUrl || editItem?.photo_url as string || '';
    if (editItem) {
      setPrefects(prev => prev.map(p => p.id === editItem.id ? { ...p, ...formData, photo_url: photoUrl } : p));
      toast.success('Prefect updated!');
    } else {
      const newPrefect: Prefect = { id: Date.now().toString(), name: formData.name, position: formData.position, photo_url: photoUrl };
      setPrefects(prev => [...prev, newPrefect]);
      toast.success('Prefect added!');
    }
    closeModal();
  };

  const handleSaveArticle = () => {
    const imageUrl = uploadedImageUrl || editItem?.featured_image as string || '';
    if (editItem) {
      setArticles(prev => prev.map(a => a.id === editItem.id ? { ...a, ...formData, featured_image: imageUrl } : a));
      toast.success('Article updated!');
    } else {
      const newArticle: Article = {
        id: Date.now().toString(), title: formData.title, content: formData.content,
        author: formData.author, category: formData.category, tags: [],
        featured_image: imageUrl, created_at: new Date().toISOString(),
      };
      setArticles(prev => [newArticle, ...prev]);
      toast.success('Article created!');
    }
    closeModal();
  };

  const handleSaveAnnouncement = () => {
    if (editItem) {
      setAnnouncements(prev => prev.map(a => a.id === editItem.id ? { ...a, ...formData } : a));
      toast.success('Announcement updated!');
    } else {
      const newAnn: Announcement = { id: Date.now().toString(), title: formData.title, content: formData.content, created_at: new Date().toISOString() };
      setAnnouncements(prev => [newAnn, ...prev]);
      toast.success('Announcement published!');
    }
    closeModal();
  };

  const handleGalleryUpload = async (file: File) => {
    setUploadLoading(true);
    const preview = URL.createObjectURL(file);
    setImagePreview(preview);
    const result = await uploadImage(BUCKETS.SCHOOL_IMAGES, file, 'gallery');
    setUploadLoading(false);
    const url = result?.url || preview;
    const newItem: GalleryItem = {
      id: Date.now().toString(), title: galleryTitle || file.name.split('.')[0],
      image_url: url, category: galleryCategory, created_at: new Date().toISOString(),
    };
    setGallery(prev => [newItem, ...prev]);
    toast.success('Photo added to gallery!');
  };

  const sidebarItems: { icon: React.ReactNode; label: string; section: AdminSection }[] = [
    { icon: <FaTachometerAlt size={14} />, label: 'Dashboard', section: 'dashboard' },
    { icon: <FaCamera size={14} />, label: 'School Logo', section: 'logo' },
    { icon: <FaImages size={14} />, label: 'Hero Slider', section: 'hero' },
    { icon: <FaUsers size={14} />, label: 'Teachers', section: 'teachers' },
    { icon: <FaStar size={14} />, label: 'Prefects', section: 'prefects' },
    { icon: <FaImages size={14} />, label: 'Gallery', section: 'gallery' },
    { icon: <FaNewspaper size={14} />, label: 'Articles', section: 'articles' },
    { icon: <FaBullhorn size={14} />, label: 'Announcements', section: 'announcements' },
    { icon: <FaCog size={14} />, label: 'Settings', section: 'settings' },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside className={`admin-sidebar w-64 flex-shrink-0 fixed inset-y-0 left-0 z-40 flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="p-4 border-b border-blue-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-lg p-1 flex-shrink-0">
              <img src="/logo.png" alt="Logo" className="w-full h-full object-contain"
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>
            <div>
              <p className="text-white text-xs font-bold leading-tight">St. Peter's SS Rwera</p>
              <p className="text-yellow-400 text-xs">Admin Panel</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {sidebarItems.map(item => (
            <SidebarItem key={item.section} {...item} active={activeSection}
              onClick={(s) => { setActiveSection(s); setSidebarOpen(false); }} />
          ))}
        </nav>

        <div className="p-4 border-t border-blue-800">
          <button onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-red-300 hover:text-white hover:bg-red-700/50 transition-all duration-200 text-sm">
            <FaSignOutAlt size={14} />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main Content */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="bg-white shadow-sm px-4 py-3 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-gray-100">
              <FaBars size={18} />
            </button>
            <h1 className="font-bold text-blue-900 text-sm md:text-base">
              {sidebarItems.find(i => i.section === activeSection)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden md:block text-xs text-gray-500 bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">
              ● Online
            </span>
            <div className="w-8 h-8 bg-blue-900 rounded-full flex items-center justify-center">
              <FaUser size={12} className="text-white" />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 md:p-6">

          {/* DASHBOARD */}
          {activeSection === 'dashboard' && (
            <div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Teachers', value: teachers.length, icon: FaUsers, color: 'bg-blue-500', onClick: () => setActiveSection('teachers') },
                  { label: 'Prefects', value: prefects.length, icon: FaStar, color: 'bg-yellow-500', onClick: () => setActiveSection('prefects') },
                  { label: 'Gallery Photos', value: gallery.length, icon: FaImages, color: 'bg-green-600', onClick: () => setActiveSection('gallery') },
                  { label: 'Articles', value: articles.length, icon: FaNewspaper, color: 'bg-purple-600', onClick: () => setActiveSection('articles') },
                ].map((stat, i) => (
                  <button key={i} onClick={stat.onClick}
                    className="bg-white rounded-xl p-5 shadow-sm hover:shadow-md transition-all duration-200 text-left group">
                    <div className="flex items-center justify-between mb-3">
                      <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <stat.icon size={18} className="text-white" />
                      </div>
                      <FaChartBar size={12} className="text-gray-300" />
                    </div>
                    <div className="text-2xl font-bold text-blue-900">{stat.value}</div>
                    <div className="text-gray-500 text-xs mt-0.5">{stat.label}</div>
                  </button>
                ))}
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-5 shadow-sm">
                  <h3 className="font-bold text-blue-900 mb-4 flex items-center gap-2"><FaBullhorn size={14} /> Recent Announcements</h3>
                  <div className="space-y-3">
                    {announcements.slice(0, 3).map(ann => (
                      <div key={ann.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-semibold text-blue-900 line-clamp-1">{ann.title}</p>
                          <p className="text-xs text-gray-400 mt-0.5">{format(new Date(ann.created_at), 'MMM d, yyyy')}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white rounded-xl p-5 shadow-sm">
                  <h3 className="font-bold text-blue-900 mb-4 flex items-center gap-2"><FaSchool size={14} /> Quick Actions</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'Add Teacher', icon: FaUsers, section: 'teachers' as AdminSection },
                      { label: 'Add Prefect', icon: FaStar, section: 'prefects' as AdminSection },
                      { label: 'Add Photo', icon: FaImages, section: 'gallery' as AdminSection },
                      { label: 'New Article', icon: FaNewspaper, section: 'articles' as AdminSection },
                      { label: 'Announce', icon: FaBullhorn, section: 'announcements' as AdminSection },
                      { label: 'Settings', icon: FaCog, section: 'settings' as AdminSection },
                    ].map((action, i) => (
                      <button key={i} onClick={() => setActiveSection(action.section)}
                        className="flex items-center gap-2 p-3 bg-gray-50 hover:bg-blue-50 rounded-lg text-sm font-medium text-gray-700 hover:text-blue-900 transition-all duration-200">
                        <action.icon size={14} className="text-blue-600" />
                        {action.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* LOGO MANAGEMENT */}
          {activeSection === 'logo' && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h3 className="font-bold text-blue-900 mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>School Logo Management</h3>
                <div className="flex items-center gap-6 mb-6">
                  <div className="w-24 h-24 border-4 border-blue-100 rounded-xl overflow-hidden flex-shrink-0">
                    <img src={logoUrl} alt="Current Logo" className="w-full h-full object-contain"
                      onError={(e) => { (e.target as HTMLImageElement).src = '/logo.png'; }} />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800">Current Logo</p>
                    <p className="text-sm text-gray-500 mt-1">Upload a new logo to replace the current one.</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Upload New Logo (from your device)</label>
                    <ImageDropZone
                      onUpload={handleLogoUpload}
                      preview={logoUrl !== '/logo.png' && !logoUrl.startsWith('/') ? logoUrl : undefined}
                      loading={uploadLoading}
                      label="Click or drag logo image here"
                    />
                  </div>
                  <div className="border-t pt-4">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Or Enter Logo URL</label>
                    <div className="flex gap-2">
                      <input type="url" value={logoInput} onChange={e => setLogoInput(e.target.value)}
                        placeholder="https://example.com/logo.png" className="form-input flex-1" />
                      <button onClick={() => { if (logoInput) { setLogoUrl(logoInput); toast.success('Logo URL saved!'); } }}
                        className="bg-blue-900 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition-colors text-sm font-semibold">
                        Apply
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* HERO SLIDER */}
          {activeSection === 'hero' && (
            <div>
              <div className="bg-white rounded-xl p-6 shadow-sm mb-4">
                <h3 className="font-bold text-blue-900 mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>Add Hero Slide Image</h3>
                <p className="text-sm text-gray-500 mb-4">Upload images to display in the homepage hero slider. Images must be uploaded from your device.</p>
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Slide Title</label>
                    <input type="text" placeholder="Welcome to Our School" className="form-input" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Slide Subtitle</label>
                    <input type="text" placeholder="Excellence in Education" className="form-input" />
                  </div>
                </div>
                <ImageDropZone
                  onUpload={async (file) => { await handleImageUpload(file, 'hero'); toast.success('Hero slide image uploaded!'); }}
                  preview={imagePreview}
                  loading={uploadLoading}
                  label="Click or drag hero slide image here (recommended: 1200x627px)"
                />
                <button className="mt-4 btn-primary text-sm">
                  <FaPlus size={12} /> Add Slide
                </button>
              </div>
              <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                <p className="text-sm text-blue-800"><span className="font-bold">Note:</span> Hero slider images must be uploaded directly from your device. URLs are not accepted for security.</p>
              </div>
            </div>
          )}

          {/* TEACHERS */}
          {activeSection === 'teachers' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-gray-500 text-sm">{teachers.length} teachers</p>
                <button onClick={() => openModal('add-teacher')} className="btn-primary text-sm">
                  <FaPlus size={12} /> Add Teacher
                </button>
              </div>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <table className="w-full">
                  <thead>
                    <tr>
                      <th className="table-header">Photo</th>
                      <th className="table-header">Name</th>
                      <th className="table-header hidden md:table-cell">Position</th>
                      <th className="table-header hidden lg:table-cell">Bio</th>
                      <th className="table-header text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teachers.map(t => (
                      <tr key={t.id} className="hover:bg-gray-50 transition-colors">
                        <td className="table-cell">
                          <div className="w-10 h-10 bg-blue-100 rounded-full overflow-hidden">
                            {t.photo_url ? <img src={t.photo_url} alt={t.name} className="w-full h-full object-cover" /> :
                              <div className="w-full h-full flex items-center justify-center"><FaUser size={16} className="text-blue-400" /></div>}
                          </div>
                        </td>
                        <td className="table-cell font-semibold text-blue-900 text-sm">{t.name}</td>
                        <td className="table-cell hidden md:table-cell text-sm text-yellow-700">{t.position}</td>
                        <td className="table-cell hidden lg:table-cell text-xs text-gray-500 max-w-xs truncate">{t.bio}</td>
                        <td className="table-cell">
                          <div className="flex items-center justify-center gap-2">
                            <button onClick={() => openModal('edit-teacher', t as unknown as Record<string, unknown>)}
                              className="w-8 h-8 bg-blue-100 hover:bg-blue-200 rounded-lg flex items-center justify-center text-blue-700 transition-colors">
                              <FaEdit size={12} />
                            </button>
                            <button onClick={() => { setTeachers(prev => prev.filter(x => x.id !== t.id)); toast.success('Teacher removed!'); }}
                              className="w-8 h-8 bg-red-100 hover:bg-red-200 rounded-lg flex items-center justify-center text-red-600 transition-colors">
                              <FaTrash size={12} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* PREFECTS */}
          {activeSection === 'prefects' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-gray-500 text-sm">{prefects.length} prefects</p>
                <button onClick={() => openModal('add-prefect')} className="btn-primary text-sm">
                  <FaPlus size={12} /> Add Prefect
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {prefects.map(p => (
                  <div key={p.id} className="bg-white rounded-xl overflow-hidden shadow-sm group text-center">
                    <div className="h-28 bg-yellow-50 flex items-center justify-center relative">
                      {p.photo_url ? <img src={p.photo_url} alt={p.name} className="w-full h-full object-cover" /> :
                        <div className="w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center"><FaUser size={24} className="text-white" /></div>}
                      <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => openModal('edit-prefect', p as unknown as Record<string, unknown>)}
                          className="w-6 h-6 bg-blue-900 rounded flex items-center justify-center text-white text-xs">
                          <FaEdit size={9} />
                        </button>
                        <button onClick={() => { setPrefects(prev => prev.filter(x => x.id !== p.id)); toast.success('Prefect removed!'); }}
                          className="w-6 h-6 bg-red-600 rounded flex items-center justify-center text-white text-xs">
                          <FaTrash size={9} />
                        </button>
                      </div>
                    </div>
                    <div className="p-2">
                      <p className="text-blue-900 text-xs font-bold leading-tight">{p.name}</p>
                      <p className="text-yellow-600 text-xs">{p.position}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* GALLERY */}
          {activeSection === 'gallery' && (
            <div>
              <div className="bg-white rounded-xl p-5 shadow-sm mb-5">
                <h3 className="font-bold text-blue-900 mb-4">Add Photos to Gallery</h3>
                <div className="grid sm:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Photo Title</label>
                    <input type="text" value={galleryTitle} onChange={e => setGalleryTitle(e.target.value)}
                      placeholder="E.g. Sports Day 2024" className="form-input" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Category</label>
                    <select value={galleryCategory} onChange={e => setGalleryCategory(e.target.value)} className="form-input">
                      {['Classrooms', 'Sports', 'Events', 'Library', 'Activities', 'Ceremonies'].map(c => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <ImageDropZone
                  onUpload={handleGalleryUpload}
                  loading={uploadLoading}
                  label="Click or drag photo here to upload to gallery"
                />
                <p className="text-xs text-gray-400 mt-2">Only file uploads accepted. URLs are not allowed for gallery photos.</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {gallery.map(item => (
                  <div key={item.id} className="group relative rounded-xl overflow-hidden shadow-sm h-36">
                    <img src={item.image_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                      <p className="text-white text-xs font-semibold px-2 text-center">{item.title}</p>
                      <button onClick={() => { setGallery(prev => prev.filter(x => x.id !== item.id)); toast.success('Photo removed!'); }}
                        className="bg-red-600 text-white px-3 py-1 rounded-lg text-xs font-semibold hover:bg-red-500 transition-colors flex items-center gap-1">
                        <FaTrash size={9} /> Remove
                      </button>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                      <span className="bg-yellow-400 text-blue-900 text-xs font-bold px-2 py-0.5 rounded-full">{item.category}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ARTICLES */}
          {activeSection === 'articles' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-gray-500 text-sm">{articles.length} articles</p>
                <button onClick={() => openModal('add-article')} className="btn-primary text-sm">
                  <FaPlus size={12} /> New Article
                </button>
              </div>
              <div className="space-y-3">
                {articles.map(a => (
                  <div key={a.id} className="bg-white rounded-xl p-4 shadow-sm flex items-start gap-4 hover:shadow-md transition-all duration-200">
                    {a.featured_image && <img src={a.featured_image} alt={a.title} className="w-16 h-16 object-cover rounded-lg flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-bold text-blue-900 text-sm line-clamp-1">{a.title}</h4>
                        <span className="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full flex-shrink-0">{a.category}</span>
                      </div>
                      <p className="text-gray-500 text-xs mt-1 line-clamp-2">{a.content}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                        <span>By {a.author}</span>
                        <span>{format(new Date(a.created_at), 'MMM d, yyyy')}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button onClick={() => openModal('edit-article', a as unknown as Record<string, unknown>)}
                        className="w-8 h-8 bg-blue-100 hover:bg-blue-200 rounded-lg flex items-center justify-center text-blue-700 transition-colors">
                        <FaEdit size={12} />
                      </button>
                      <button onClick={() => { setArticles(prev => prev.filter(x => x.id !== a.id)); toast.success('Article deleted!'); }}
                        className="w-8 h-8 bg-red-100 hover:bg-red-200 rounded-lg flex items-center justify-center text-red-600 transition-colors">
                        <FaTrash size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ANNOUNCEMENTS */}
          {activeSection === 'announcements' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-gray-500 text-sm">{announcements.length} announcements</p>
                <button onClick={() => openModal('add-announcement')} className="btn-primary text-sm">
                  <FaPlus size={12} /> New Announcement
                </button>
              </div>
              <div className="space-y-3">
                {announcements.map(ann => (
                  <div key={ann.id} className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-200">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h4 className="font-bold text-blue-900 mb-1">{ann.title}</h4>
                        <p className="text-gray-500 text-sm line-clamp-2">{ann.content}</p>
                        <p className="text-gray-400 text-xs mt-2">{format(new Date(ann.created_at), 'MMMM d, yyyy')}</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => openModal('edit-announcement', ann as unknown as Record<string, unknown>)}
                          className="w-8 h-8 bg-blue-100 hover:bg-blue-200 rounded-lg flex items-center justify-center text-blue-700 transition-colors">
                          <FaEdit size={12} />
                        </button>
                        <button onClick={() => { setAnnouncements(prev => prev.filter(x => x.id !== ann.id)); toast.success('Announcement deleted!'); }}
                          className="w-8 h-8 bg-red-100 hover:bg-red-200 rounded-lg flex items-center justify-center text-red-600 transition-colors">
                          <FaTrash size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {activeSection === 'settings' && (
            <div className="max-w-2xl space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h3 className="font-bold text-blue-900 mb-5" style={{ fontFamily: 'Playfair Display, serif' }}>School Information</h3>
                <div className="space-y-4">
                  {[
                    { label: 'School Name', key: 'school_name' },
                    { label: 'Email Address', key: 'email' },
                    { label: 'Phone Number', key: 'phone' },
                    { label: 'WhatsApp Contact', key: 'whatsapp' },
                    { label: 'Location', key: 'location' },
                  ].map(field => (
                    <div key={field.key}>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">{field.label}</label>
                      <input
                        type="text"
                        value={settingsForm[field.key as keyof typeof settingsForm]}
                        onChange={e => setSettingsForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                        className="form-input"
                      />
                    </div>
                  ))}
                  <button onClick={() => toast.success('Settings saved!')} className="btn-primary text-sm w-full justify-center">
                    <FaCheck size={12} /> Save School Information
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h3 className="font-bold text-blue-900 mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>Online Learning Link</h3>
                <p className="text-sm text-gray-500 mb-3">Update the URL for the Online Learning portal button.</p>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <FaLink className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                    <input type="url" value={learningLink} onChange={e => setLearningLink(e.target.value)}
                      className="form-input pl-9" placeholder="https://dotshule.ug/dot" />
                  </div>
                  <button onClick={() => toast.success('Learning link updated!')}
                    className="bg-blue-900 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition-colors text-sm font-semibold whitespace-nowrap">
                    Save Link
                  </button>
                </div>
                <a href={learningLink} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-blue-600 hover:text-blue-800 text-xs mt-2 transition-colors">
                  <FaExternalLinkAlt size={10} /> Test Link
                </a>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODALS */}
      {showModal && (
        <>
          {/* Teacher Modal */}
          {(modalType === 'add-teacher' || modalType === 'edit-teacher') && (
            <Modal title={modalType === 'add-teacher' ? 'Add Teacher' : 'Edit Teacher'} onClose={closeModal}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Full Name *</label>
                  <input type="text" value={formData.name || ''} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                    placeholder="Mr./Ms. Full Name" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Position/Subject *</label>
                  <input type="text" value={formData.position || ''} onChange={e => setFormData(p => ({ ...p, position: e.target.value }))}
                    placeholder="Mathematics Teacher" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Bio</label>
                  <textarea value={formData.bio || ''} onChange={e => setFormData(p => ({ ...p, bio: e.target.value }))}
                    rows={3} placeholder="Brief bio..." className="form-input resize-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Photo (Upload from Device Only)
                  </label>
                  <ImageDropZone
                    onUpload={f => handleImageUpload(f, 'teachers')}
                    preview={imagePreview}
                    loading={uploadLoading}
                    label="Upload teacher photo from your device"
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={handleSaveTeacher} className="btn-primary flex-1 justify-center text-sm">
                    <FaCheck size={12} /> {modalType === 'add-teacher' ? 'Add Teacher' : 'Save Changes'}
                  </button>
                  <button onClick={closeModal} className="flex-1 border border-gray-200 py-2.5 rounded-lg text-sm font-semibold hover:bg-gray-50 transition-colors">
                    Cancel
                  </button>
                </div>
              </div>
            </Modal>
          )}

          {/* Prefect Modal */}
          {(modalType === 'add-prefect' || modalType === 'edit-prefect') && (
            <Modal title={modalType === 'add-prefect' ? 'Add Prefect' : 'Edit Prefect'} onClose={closeModal}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Full Name *</label>
                  <input type="text" value={formData.name || ''} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                    placeholder="Student Full Name" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Position *</label>
                  <input type="text" value={formData.position || ''} onChange={e => setFormData(p => ({ ...p, position: e.target.value }))}
                    placeholder="Head Prefect" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Photo (Upload from Device Only)</label>
                  <ImageDropZone onUpload={f => handleImageUpload(f, 'prefects')} preview={imagePreview} loading={uploadLoading} />
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={handleSavePrefect} className="btn-primary flex-1 justify-center text-sm">
                    <FaCheck size={12} /> {modalType === 'add-prefect' ? 'Add Prefect' : 'Save Changes'}
                  </button>
                  <button onClick={closeModal} className="flex-1 border border-gray-200 py-2.5 rounded-lg text-sm font-semibold hover:bg-gray-50 transition-colors">Cancel</button>
                </div>
              </div>
            </Modal>
          )}

          {/* Article Modal */}
          {(modalType === 'add-article' || modalType === 'edit-article') && (
            <Modal title={modalType === 'add-article' ? 'New Article' : 'Edit Article'} onClose={closeModal}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Title *</label>
                  <input type="text" value={formData.title || ''} onChange={e => setFormData(p => ({ ...p, title: e.target.value }))}
                    placeholder="Article title" className="form-input" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Author</label>
                    <input type="text" value={formData.author || ''} onChange={e => setFormData(p => ({ ...p, author: e.target.value }))}
                      placeholder="Author name" className="form-input" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Category</label>
                    <select value={formData.category || ''} onChange={e => setFormData(p => ({ ...p, category: e.target.value }))} className="form-input">
                      {['Education', 'Student Resources', 'Leadership', 'News', 'Science', 'Sports'].map(c => <option key={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Content *</label>
                  <textarea value={formData.content || ''} onChange={e => setFormData(p => ({ ...p, content: e.target.value }))}
                    rows={5} placeholder="Write article content..." className="form-input resize-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Featured Image (Upload Only)</label>
                  <ImageDropZone onUpload={f => handleImageUpload(f, 'articles')} preview={imagePreview} loading={uploadLoading} />
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={handleSaveArticle} className="btn-primary flex-1 justify-center text-sm">
                    <FaCheck size={12} /> {modalType === 'add-article' ? 'Publish' : 'Update'}
                  </button>
                  <button onClick={closeModal} className="flex-1 border border-gray-200 py-2.5 rounded-lg text-sm font-semibold hover:bg-gray-50 transition-colors">Cancel</button>
                </div>
              </div>
            </Modal>
          )}

          {/* Announcement Modal */}
          {(modalType === 'add-announcement' || modalType === 'edit-announcement') && (
            <Modal title={modalType === 'add-announcement' ? 'New Announcement' : 'Edit Announcement'} onClose={closeModal}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Title *</label>
                  <input type="text" value={formData.title || ''} onChange={e => setFormData(p => ({ ...p, title: e.target.value }))}
                    placeholder="Announcement title" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Content *</label>
                  <textarea value={formData.content || ''} onChange={e => setFormData(p => ({ ...p, content: e.target.value }))}
                    rows={5} placeholder="Write announcement content..." className="form-input resize-none" />
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={handleSaveAnnouncement} className="btn-primary flex-1 justify-center text-sm">
                    <FaCheck size={12} /> {modalType === 'add-announcement' ? 'Publish' : 'Update'}
                  </button>
                  <button onClick={closeModal} className="flex-1 border border-gray-200 py-2.5 rounded-lg text-sm font-semibold hover:bg-gray-50 transition-colors">Cancel</button>
                </div>
              </div>
            </Modal>
          )}
        </>
      )}
    </div>
  );
};

export default AdminDashboard;
