import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaWhatsapp, FaPaperPlane } from 'react-icons/fa';
import { SCHOOL_INFO } from '../lib/constants';
import toast from 'react-hot-toast';

const Reveal: React.FC<{ children: React.ReactNode; delay?: number; className?: string }> = ({ children, delay = 0, className }) => {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });
  return (
    <div ref={ref} className={`transition-all duration-700 ${className ?? ''}`}
      style={{ transitionDelay: `${delay}ms`, opacity: inView ? 1 : 0, transform: inView ? 'translateY(0)' : 'translateY(20px)' }}>
      {children}
    </div>
  );
};

const Contact: React.FC = () => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error('Please fill in all required fields.');
      return;
    }
    setSending(true);
    await new Promise(r => setTimeout(r, 1500));
    setSending(false);
    toast.success('Message sent! We will get back to you shortly.');
    setForm({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  const contacts = [
    {
      icon: FaPhone,
      label: 'Head Teacher',
      value: SCHOOL_INFO.headTeacherPhone,
      link: `tel:${SCHOOL_INFO.headTeacherPhone}`,
      color: 'bg-blue-900',
    },
    {
      icon: FaEnvelope,
      label: 'Email Address',
      value: SCHOOL_INFO.email,
      link: `mailto:${SCHOOL_INFO.email}`,
      color: 'bg-yellow-500',
    },
    {
      icon: FaWhatsapp,
      label: 'WhatsApp',
      value: SCHOOL_INFO.whatsappContact,
      link: `https://wa.me/${SCHOOL_INFO.whatsappContact.replace(/\D/g, '')}`,
      color: 'bg-green-600',
    },
    {
      icon: FaMapMarkerAlt,
      label: 'Location',
      value: SCHOOL_INFO.location,
      link: 'https://maps.google.com/?q=Rwera+Ntungamo+Uganda',
      color: 'bg-red-600',
    },
  ];

  return (
    <div>
      {/* Hero */}
      <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 py-16 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full -translate-y-1/2 translate-x-1/3" />
        </div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="inline-block bg-yellow-400 text-blue-900 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">Get In Touch</div>
          <h1 className="text-3xl md:text-5xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>Contact Us</h1>
        </div>
      </div>

      {/* Contact Cards */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {contacts.map((c, i) => (
              <Reveal key={i} delay={i * 100}>
                <a href={c.link} target={c.label === 'Location' ? '_blank' : undefined} rel={c.label === 'Location' ? 'noopener noreferrer' : undefined}
                  className="block text-center p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group border border-gray-100">
                  <div className={`w-14 h-14 ${c.color} rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                    <c.icon size={24} className="text-white" />
                  </div>
                  <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">{c.label}</p>
                  <p className="text-blue-900 font-semibold text-sm leading-snug break-all">{c.value}</p>
                </a>
              </Reveal>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-10">
            {/* Contact Form */}
            <Reveal>
              <div className="bg-gray-50 rounded-2xl p-8">
                <h2 className="text-2xl font-bold text-blue-900 mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>Send Us a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">Full Name *</label>
                      <input type="text" name="name" value={form.name} onChange={handleChange} required placeholder="Your full name"
                        className="form-input" />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">Email Address *</label>
                      <input type="email" name="email" value={form.email} onChange={handleChange} required placeholder="your@email.com"
                        className="form-input" />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">Phone Number</label>
                      <input type="tel" name="phone" value={form.phone} onChange={handleChange} placeholder="+256 ..."
                        className="form-input" />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">Subject *</label>
                      <select name="subject" value={form.subject} onChange={handleChange} className="form-input" required>
                        <option value="">Select subject</option>
                        <option value="Admission Inquiry">Admission Inquiry</option>
                        <option value="Academic Information">Academic Information</option>
                        <option value="Fee Payment">Fee Payment</option>
                        <option value="Student Welfare">Student Welfare</option>
                        <option value="General Inquiry">General Inquiry</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Message *</label>
                    <textarea name="message" value={form.message} onChange={handleChange} required rows={5} placeholder="Write your message here..."
                      className="form-input resize-none" />
                  </div>
                  <button type="submit" disabled={sending}
                    className="w-full bg-blue-900 hover:bg-blue-800 text-white py-3.5 rounded-lg font-bold flex items-center justify-center gap-2 transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed">
                    {sending ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <FaPaperPlane size={14} />
                        Send Message
                      </>
                    )}
                  </button>
                </form>
              </div>
            </Reveal>

            {/* Map + Info */}
            <Reveal delay={200}>
              <div className="space-y-6">
                {/* Map placeholder */}
                <div className="rounded-2xl overflow-hidden shadow-md h-72 bg-blue-100 relative">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127618.38978088!2d29.89!3d-0.89!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x19d97b01b3cc00cf%3A0x3c01fd73f1ea5da0!2sNtungamo%2C%20Uganda!5e0!3m2!1sen!2s!4v1234567890"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="School Location Map"
                  />
                  <div className="absolute bottom-3 left-3 right-3">
                    <div className="bg-white/95 backdrop-blur-sm rounded-xl p-3 shadow-md">
                      <p className="text-blue-900 font-bold text-sm">📍 St. Peter's SS Rwera</p>
                      <p className="text-gray-600 text-xs">Rwera, Ntungamo District, Uganda</p>
                    </div>
                  </div>
                </div>

                {/* WhatsApp Group */}
                <div className="bg-green-50 border border-green-200 rounded-2xl p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <FaWhatsapp size={24} className="text-white" />
                    </div>
                    <div>
                      <h3 className="font-bold text-green-800 mb-1">Join Our WhatsApp Community</h3>
                      <p className="text-green-700 text-sm mb-3">{SCHOOL_INFO.whatsappGroupText}</p>
                      <a href={SCHOOL_INFO.whatsappGroupLink} target="_blank" rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-5 py-2 rounded-lg font-semibold text-sm transition-all duration-200">
                        <FaWhatsapp size={14} />
                        Join Parents & Teachers Group
                      </a>
                    </div>
                  </div>
                </div>

                {/* School hours */}
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6">
                  <h3 className="font-bold text-blue-900 mb-3">🕐 Office Hours</h3>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex justify-between">
                      <span>Monday – Friday</span>
                      <span className="font-semibold text-blue-900">8:00 AM – 5:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Saturday</span>
                      <span className="font-semibold text-blue-900">8:00 AM – 1:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sunday</span>
                      <span className="font-semibold text-red-500">Closed</span>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
