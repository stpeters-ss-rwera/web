import React from 'react';
import { useInView } from 'react-intersection-observer';
import { FaExternalLinkAlt, FaLock, FaUserCircle, FaKey, FaBook, FaLaptop, FaGlobe } from 'react-icons/fa';
import { SCHOOL_INFO } from '../lib/constants';

const Reveal: React.FC<{ children: React.ReactNode; delay?: number; className?: string }> = ({ children, delay = 0, className }) => {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });
  return (
    <div ref={ref} className={`transition-all duration-700 ${className ?? ''}`}
      style={{ transitionDelay: `${delay}ms`, opacity: inView ? 1 : 0, transform: inView ? 'translateY(0)' : 'translateY(20px)' }}>
      {children}
    </div>
  );
};

const OnlineLearning: React.FC = () => {
  const features = [
    { icon: FaBook, title: 'Digital Study Materials', desc: 'Access comprehensive study notes, past papers, and reference materials for all subjects.' },
    { icon: FaLaptop, title: 'Interactive Lessons', desc: 'Engage with interactive lessons and multimedia content for better understanding.' },
    { icon: FaGlobe, title: 'Learn Anywhere', desc: 'Access learning resources from home, school, or anywhere with internet connectivity.' },
    { icon: FaLock, title: 'Secure Access', desc: 'Your personal credentials ensure secure, private access to all learning materials.' },
  ];

  const steps = [
    { step: '01', title: 'Get Your Credentials', desc: 'Obtain your username and password from the School System Administrator.' },
    { step: '02', title: 'Click Access Button', desc: 'Click the "Access Online Learning" button below to open the platform.' },
    { step: '03', title: 'Login Securely', desc: 'Enter your username and assigned password to log in.' },
    { step: '04', title: 'Start Learning', desc: 'Access all available learning resources and materials for your subjects.' },
  ];

  return (
    <div>
      {/* Hero */}
      <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full translate-y-1/2 -translate-x-1/3" />
        </div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="w-20 h-20 bg-yellow-400 rounded-full mx-auto mb-6 flex items-center justify-center shadow-2xl">
            <FaLaptop size={36} className="text-blue-900" />
          </div>
          <div className="inline-block bg-yellow-400 text-blue-900 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">
            Digital Education
          </div>
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            Online Learning Portal
          </h1>
          <p className="text-blue-200 text-lg max-w-2xl mx-auto">
            Access world-class educational resources from anywhere, at any time.
          </p>
        </div>
      </div>

      {/* Access Card */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <Reveal>
              <div className="bg-gradient-to-br from-blue-900 to-blue-800 rounded-3xl p-8 md:p-12 text-center shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-48 bg-yellow-400/10 rounded-full -translate-y-1/4 translate-x-1/4" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/4 -translate-x-1/4" />

                <div className="relative z-10">
                  <div className="w-20 h-20 bg-white/10 backdrop-blur-sm rounded-full mx-auto mb-6 flex items-center justify-center border border-white/20">
                    <FaLock size={32} className="text-yellow-400" />
                  </div>

                  <h2 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                    Secure Access Required
                  </h2>

                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-white/20">
                    <p className="text-white text-base leading-relaxed">
                      Use your <span className="text-yellow-400 font-bold">username</span> provided by the School System Administrator and your{' '}
                      <span className="text-yellow-400 font-bold">assigned password</span> to access online learning resources.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                      <FaUserCircle size={24} className="text-yellow-400 mx-auto mb-2" />
                      <p className="text-white text-sm font-semibold">Your Username</p>
                      <p className="text-blue-200 text-xs mt-1">Provided by Administrator</p>
                    </div>
                    <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                      <FaKey size={24} className="text-yellow-400 mx-auto mb-2" />
                      <p className="text-white text-sm font-semibold">Your Password</p>
                      <p className="text-blue-200 text-xs mt-1">Assigned by Administrator</p>
                    </div>
                  </div>

                  <a
                    href={SCHOOL_INFO.onlineLearningUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 bg-yellow-400 hover:bg-yellow-300 text-blue-900 px-10 py-4 rounded-xl font-bold text-lg transition-all duration-300 hover:scale-105 shadow-xl"
                  >
                    <FaExternalLinkAlt size={18} />
                    Access Online Learning
                  </a>

                  <p className="text-blue-300 text-xs mt-4">
                    Opens in a new tab • Secure connection required
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-12">
            <h2 className="section-title">What You Can Access</h2>
            <p className="section-subtitle">Our online learning platform provides comprehensive resources to support your studies</p>
          </Reveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <Reveal key={i} delay={i * 100}>
                <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 text-center group">
                  <div className="w-14 h-14 bg-blue-100 rounded-2xl mx-auto mb-4 flex items-center justify-center group-hover:bg-blue-900 transition-colors duration-300">
                    <f.icon size={24} className="text-blue-900 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="font-bold text-blue-900 text-lg mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>{f.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-12">
            <span className="inline-block bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-3">How It Works</span>
            <h2 className="section-title">Getting Started in 4 Simple Steps</h2>
          </Reveal>
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
              <div className="hidden lg:block absolute top-10 left-[12.5%] right-[12.5%] h-0.5 bg-blue-100 z-0" />
              {steps.map((s, i) => (
                <Reveal key={i} delay={i * 100}>
                  <div className="text-center relative z-10">
                    <div className="w-20 h-20 bg-blue-900 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                      <span className="text-yellow-400 font-bold text-xl">{s.step}</span>
                    </div>
                    <h4 className="font-bold text-blue-900 text-base mb-2">{s.title}</h4>
                    <p className="text-gray-500 text-sm leading-relaxed">{s.desc}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Need Help */}
      <section className="py-16 bg-blue-900">
        <div className="container mx-auto px-4 text-center">
          <Reveal>
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              Need Help with Access?
            </h2>
            <p className="text-blue-200 mb-6">
              Contact the School Administrator to get your login credentials or reset your password.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a href={`tel:${SCHOOL_INFO.headTeacherPhone}`}
                className="bg-yellow-400 text-blue-900 px-6 py-3 rounded-lg font-bold hover:bg-yellow-300 transition-colors flex items-center gap-2">
                📞 Call Head Teacher
              </a>
              <a href={`mailto:${SCHOOL_INFO.email}`}
                className="bg-white/20 border border-white/30 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors flex items-center gap-2">
                ✉️ Send Email
              </a>
              <a href={`https://wa.me/${SCHOOL_INFO.whatsappContact.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer"
                className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-500 transition-colors flex items-center gap-2">
                💬 WhatsApp
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
};

export default OnlineLearning;
