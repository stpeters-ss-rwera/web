import React from 'react';
import { FaWhatsapp } from 'react-icons/fa';
import { SCHOOL_INFO } from '../lib/constants';

const WhatsAppFloat: React.FC = () => {
  return (
    <a
      href={`https://wa.me/${SCHOOL_INFO.whatsappContact.replace(/\D/g, '')}`}
      target="_blank"
      rel="noopener noreferrer"
      className="whatsapp-float"
      aria-label="Chat on WhatsApp"
      title="Chat with us on WhatsApp"
    >
      <div className="relative group">
        <div className="w-14 h-14 bg-green-500 hover:bg-green-400 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 hover:scale-110">
          <FaWhatsapp size={28} className="text-white" />
        </div>
        <span className="absolute right-16 top-1/2 -translate-y-1/2 bg-white text-gray-800 text-xs font-semibold px-3 py-1.5 rounded-lg shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
          Chat with us
        </span>
      </div>
    </a>
  );
};

export default WhatsAppFloat;
