export const SCHOOL_INFO = {
  name: "ST. PETER'S SECONDARY SCHOOL – RWERA",
  shortName: "St. Peter's SS Rwera",
  motto: "Invest in Education",
  location: "Rwera, Kakukuru-Rwenanura Town Council, Ruhaama, Ntungamo District, Uganda",
  email: "stpetersssrwera2019@gmail.com",
  headTeacherPhone: "+256 782 854642",
  whatsappContact: "+256776747621",
  whatsappGroupLink: "https://chat.whatsapp.com/CXJZVsWFtk79alN8TsyPOb",
  whatsappGroupText: "Join the St Peter's SS Rwera Parents and Teachers WhatsApp Group",
  onlineLearningUrl: "https://dotshule.ug/dot",
};

export const HERO_SLIDES = [
  {
    id: 1,
    title: "Welcome to St. Peter's Secondary School",
    subtitle: "Invest in Education – Shaping Future Leaders",
    image: "https://images.pexels.com/photos/34162713/pexels-photo-34162713.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: 2,
    title: "Excellence in Academic Achievement",
    subtitle: "Providing Quality Education in Ntungamo District, Uganda",
    image: "https://images.pexels.com/photos/34211747/pexels-photo-34211747.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: 3,
    title: "Holistic Student Development",
    subtitle: "Nurturing Character, Skills, and Academic Excellence",
    image: "https://images.pexels.com/photos/7396377/pexels-photo-7396377.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: 4,
    title: "A Community of Learners",
    subtitle: "Together We Build Brighter Futures for Uganda",
    image: "https://images.pexels.com/photos/3231358/pexels-photo-3231358.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
];

export const SCHOOL_COLORS = {
  primary: "#1a3c8f",   // Deep Blue
  secondary: "#f5c518", // Gold/Yellow
  accent: "#0d6b3f",    // Green
  dark: "#0f1e3d",
  light: "#f8f9ff",
};

export const SAMPLE_TEACHERS = [
  { id: '1', name: 'Mr. John Mugisha', position: 'Head Teacher', photo_url: '', bio: 'Experienced educator with over 15 years in secondary education.' },
  { id: '2', name: 'Ms. Grace Atuhaire', position: 'Deputy Head Teacher', photo_url: '', bio: 'Passionate about student welfare and academic excellence.' },
  { id: '3', name: 'Mr. Peter Turyamureeba', position: 'Mathematics Teacher', photo_url: '', bio: 'Mathematics and Physics specialist dedicated to student success.' },
  { id: '4', name: 'Ms. Mary Nakato', position: 'English Teacher', photo_url: '', bio: 'Literature and language expert fostering communication skills.' },
  { id: '5', name: 'Mr. Samuel Byaruhanga', position: 'Science Teacher', photo_url: '', bio: 'Biology and Chemistry teacher inspiring scientific curiosity.' },
  { id: '6', name: 'Ms. Doreen Tumuheirwe', position: 'History Teacher', photo_url: '', bio: 'Social studies educator connecting past to present.' },
];

export const SAMPLE_PREFECTS = [
  { id: '1', name: 'Alice Namukasa', position: 'Head Prefect', photo_url: '' },
  { id: '2', name: 'Robert Tusiime', position: 'Deputy Head Prefect', photo_url: '' },
  { id: '3', name: 'Patricia Akello', position: 'Academic Prefect', photo_url: '' },
  { id: '4', name: 'Emmanuel Twesigye', position: 'Sports Prefect', photo_url: '' },
  { id: '5', name: 'Sophia Asiimwe', position: 'Health Prefect', photo_url: '' },
  { id: '6', name: 'Daniel Mugabe', position: 'Environment Prefect', photo_url: '' },
];

export const SAMPLE_ANNOUNCEMENTS = [
  {
    id: '1',
    title: 'First Term Examinations Schedule',
    content: 'The first term examinations will commence on the dates specified by the school administration. All students are required to prepare adequately.',
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: '2',
    title: 'Sports Day Announcement',
    content: 'The annual sports day celebrations will be held at the school grounds. Parents and guardians are cordially invited to attend.',
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: '3',
    title: 'School Fees Reminder',
    content: 'Parents and guardians are reminded to clear all outstanding school fees by the end of the first month of term.',
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

export const SAMPLE_ARTICLES = [
  {
    id: '1',
    title: 'The Importance of STEM Education in Uganda',
    content: 'Science, Technology, Engineering, and Mathematics (STEM) education plays a crucial role in the development of Uganda\'s future workforce...',
    featured_image: 'https://images.pexels.com/photos/8499579/pexels-photo-8499579.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600',
    author: 'Mr. Peter Turyamureeba',
    category: 'Education',
    tags: ['STEM', 'Science', 'Uganda', 'Education'],
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: '2',
    title: 'Study Tips for UCE Candidates',
    content: 'Preparing for the Uganda Certificate of Education (UCE) examinations requires dedication, smart study strategies, and proper time management...',
    featured_image: 'https://images.pexels.com/photos/34084890/pexels-photo-34084890.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600',
    author: 'Ms. Mary Nakato',
    category: 'Student Resources',
    tags: ['UCE', 'Study Tips', 'Exams'],
    created_at: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: '3',
    title: 'Building Leadership Skills in Secondary School',
    content: 'Leadership development is a fundamental aspect of secondary school education. At St. Peter\'s SS Rwera, we believe every student has the potential to be a leader...',
    featured_image: 'https://images.pexels.com/photos/34211745/pexels-photo-34211745.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600',
    author: 'Ms. Grace Atuhaire',
    category: 'Leadership',
    tags: ['Leadership', 'Character', 'Development'],
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

export const GALLERY_CATEGORIES = ['All', 'Classrooms', 'Sports', 'Events', 'Library', 'Activities', 'Ceremonies'];

export const SAMPLE_GALLERY = [
  { id: '1', title: 'Classroom Learning', image_url: 'https://images.pexels.com/photos/34162713/pexels-photo-34162713.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Classrooms', created_at: new Date().toISOString() },
  { id: '2', title: 'Students in Session', image_url: 'https://images.pexels.com/photos/34211747/pexels-photo-34211747.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Classrooms', created_at: new Date().toISOString() },
  { id: '3', title: 'School Assembly', image_url: 'https://images.pexels.com/photos/34211745/pexels-photo-34211745.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Events', created_at: new Date().toISOString() },
  { id: '4', title: 'Sports Activity', image_url: 'https://images.pexels.com/photos/7396377/pexels-photo-7396377.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Sports', created_at: new Date().toISOString() },
  { id: '5', title: 'Library Study', image_url: 'https://images.pexels.com/photos/34084890/pexels-photo-34084890.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Library', created_at: new Date().toISOString() },
  { id: '6', title: 'Book Resources', image_url: 'https://images.pexels.com/photos/8499579/pexels-photo-8499579.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Library', created_at: new Date().toISOString() },
  { id: '7', title: 'Girls in Class', image_url: 'https://images.pexels.com/photos/3231358/pexels-photo-3231358.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Classrooms', created_at: new Date().toISOString() },
  { id: '8', title: 'Vintage Classroom', image_url: 'https://images.pexels.com/photos/34084876/pexels-photo-34084876.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600', category: 'Classrooms', created_at: new Date().toISOString() },
];
