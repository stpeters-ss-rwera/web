import { createClient } from '@supabase/supabase-js';

// These environment variables should be set in your .env file
// VITE_SUPABASE_URL=your_supabase_project_url
// VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder_key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Storage bucket names
export const BUCKETS = {
  SCHOOL_LOGO: 'school-logo',
  SCHOOL_IMAGES: 'school-images',
};

// Helper to get public URL from storage
export const getPublicUrl = (bucket: string, path: string): string => {
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
};

// Upload image to Supabase Storage
export const uploadImage = async (
  bucket: string,
  file: File,
  folder: string = ''
): Promise<{ url: string; path: string } | null> => {
  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `${folder}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
    
    const { error } = await supabase.storage
      .from(bucket)
      .upload(fileName, file, { upsert: true });

    if (error) throw error;

    const publicUrl = getPublicUrl(bucket, fileName);
    return { url: publicUrl, path: fileName };
  } catch (error) {
    console.error('Error uploading image:', error);
    return null;
  }
};

// Delete image from Supabase Storage
export const deleteImage = async (bucket: string, path: string): Promise<boolean> => {
  try {
    const { error } = await supabase.storage.from(bucket).remove([path]);
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting image:', error);
    return false;
  }
};

export type Database = {
  teachers: {
    id: string;
    name: string;
    position: string;
    photo_url: string;
    bio: string;
    created_at: string;
  };
  prefects: {
    id: string;
    name: string;
    position: string;
    photo_url: string;
    created_at: string;
  };
  gallery: {
    id: string;
    title: string;
    image_url: string;
    category: string;
    created_at: string;
  };
  articles: {
    id: string;
    title: string;
    content: string;
    featured_image: string;
    author: string;
    tags: string[];
    category: string;
    created_at: string;
  };
  announcements: {
    id: string;
    title: string;
    content: string;
    created_at: string;
  };
  settings: {
    id: string;
    school_name: string;
    logo_url: string;
    location: string;
    email: string;
    phone: string;
    whatsapp_contact: string;
    learning_link: string;
  };
  hero_slides: {
    id: string;
    title: string;
    subtitle: string;
    image_url: string;
    order_index: number;
    created_at: string;
  };
};
