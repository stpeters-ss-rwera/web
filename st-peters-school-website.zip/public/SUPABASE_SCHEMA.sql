-- =============================================
-- ST. PETER'S SECONDARY SCHOOL – RWERA
-- Supabase PostgreSQL Database Schema
-- =============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================
-- TABLE: teachers
-- =============================================
CREATE TABLE IF NOT EXISTS teachers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(200) NOT NULL,
  position VARCHAR(200) NOT NULL,
  photo_url TEXT DEFAULT '',
  bio TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: prefects
-- =============================================
CREATE TABLE IF NOT EXISTS prefects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(200) NOT NULL,
  position VARCHAR(200) NOT NULL,
  photo_url TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: gallery
-- =============================================
CREATE TABLE IF NOT EXISTS gallery (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(300) NOT NULL,
  image_url TEXT NOT NULL,
  category VARCHAR(100) DEFAULT 'General',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: articles
-- =============================================
CREATE TABLE IF NOT EXISTS articles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(500) NOT NULL,
  content TEXT NOT NULL,
  featured_image TEXT DEFAULT '',
  author VARCHAR(200) DEFAULT 'Admin',
  category VARCHAR(100) DEFAULT 'Education',
  tags TEXT[] DEFAULT '{}',
  published BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: announcements
-- =============================================
CREATE TABLE IF NOT EXISTS announcements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(500) NOT NULL,
  content TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: hero_slides
-- =============================================
CREATE TABLE IF NOT EXISTS hero_slides (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(300) NOT NULL,
  subtitle VARCHAR(500) DEFAULT '',
  image_url TEXT NOT NULL,
  order_index INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: settings
-- =============================================
CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_name VARCHAR(300) DEFAULT 'ST. PETER''S SECONDARY SCHOOL – RWERA',
  logo_url TEXT DEFAULT '',
  location TEXT DEFAULT 'Rwera, Kakukuru-Rwenanura Town Council, Ruhaama, Ntungamo District, Uganda',
  email VARCHAR(200) DEFAULT 'stpetersssrwera2019@gmail.com',
  phone VARCHAR(50) DEFAULT '+256 782 854642',
  whatsapp_contact VARCHAR(50) DEFAULT '+256776747621',
  whatsapp_group_link TEXT DEFAULT 'https://chat.whatsapp.com/CXJZVsWFtk79alN8TsyPOb',
  learning_link TEXT DEFAULT 'https://dotshule.ug/dot',
  facebook_url TEXT DEFAULT '',
  twitter_url TEXT DEFAULT '',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default settings
INSERT INTO settings (id) VALUES (uuid_generate_v4())
ON CONFLICT DO NOTHING;

-- =============================================
-- ROW LEVEL SECURITY (RLS)
-- =============================================

-- Enable RLS on all tables
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE prefects ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE hero_slides ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Public READ policies (anyone can read)
CREATE POLICY "Public read teachers" ON teachers FOR SELECT USING (true);
CREATE POLICY "Public read prefects" ON prefects FOR SELECT USING (true);
CREATE POLICY "Public read gallery" ON gallery FOR SELECT USING (true);
CREATE POLICY "Public read articles" ON articles FOR SELECT USING (published = true);
CREATE POLICY "Public read announcements" ON announcements FOR SELECT USING (is_active = true);
CREATE POLICY "Public read hero_slides" ON hero_slides FOR SELECT USING (is_active = true);
CREATE POLICY "Public read settings" ON settings FOR SELECT USING (true);

-- Admin WRITE policies (only authenticated users can write)
CREATE POLICY "Admin insert teachers" ON teachers FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admin update teachers" ON teachers FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin delete teachers" ON teachers FOR DELETE TO authenticated USING (true);

CREATE POLICY "Admin insert prefects" ON prefects FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admin update prefects" ON prefects FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin delete prefects" ON prefects FOR DELETE TO authenticated USING (true);

CREATE POLICY "Admin insert gallery" ON gallery FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admin update gallery" ON gallery FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin delete gallery" ON gallery FOR DELETE TO authenticated USING (true);

CREATE POLICY "Admin insert articles" ON articles FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admin update articles" ON articles FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin delete articles" ON articles FOR DELETE TO authenticated USING (true);

CREATE POLICY "Admin insert announcements" ON announcements FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admin update announcements" ON announcements FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin delete announcements" ON announcements FOR DELETE TO authenticated USING (true);

CREATE POLICY "Admin insert hero_slides" ON hero_slides FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admin update hero_slides" ON hero_slides FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin delete hero_slides" ON hero_slides FOR DELETE TO authenticated USING (true);

CREATE POLICY "Admin update settings" ON settings FOR UPDATE TO authenticated USING (true);

-- =============================================
-- STORAGE BUCKETS
-- Run these in Supabase Dashboard > Storage
-- =============================================

-- Bucket 1: school-logo (for logo uploads and URL references)
-- INSERT INTO storage.buckets (id, name, public) VALUES ('school-logo', 'school-logo', true);

-- Bucket 2: school-images (for all other images)
-- INSERT INTO storage.buckets (id, name, public) VALUES ('school-images', 'school-images', true);

-- Storage RLS Policies
-- Allow public read
-- CREATE POLICY "Public read school-logo" ON storage.objects FOR SELECT USING (bucket_id = 'school-logo');
-- CREATE POLICY "Public read school-images" ON storage.objects FOR SELECT USING (bucket_id = 'school-images');

-- Allow authenticated upload
-- CREATE POLICY "Auth upload school-logo" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'school-logo');
-- CREATE POLICY "Auth upload school-images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'school-images');

-- Allow authenticated delete
-- CREATE POLICY "Auth delete school-logo" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'school-logo');
-- CREATE POLICY "Auth delete school-images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'school-images');

-- =============================================
-- SAMPLE DATA (Optional)
-- =============================================

INSERT INTO teachers (name, position, bio) VALUES
  ('Mr. John Mugisha', 'Head Teacher', 'Experienced educator with over 15 years in secondary education.'),
  ('Ms. Grace Atuhaire', 'Deputy Head Teacher', 'Passionate about student welfare and academic excellence.'),
  ('Mr. Peter Turyamureeba', 'Mathematics Teacher', 'Mathematics and Physics specialist dedicated to student success.'),
  ('Ms. Mary Nakato', 'English Teacher', 'Literature and language expert fostering communication skills.'),
  ('Mr. Samuel Byaruhanga', 'Science Teacher', 'Biology and Chemistry teacher inspiring scientific curiosity.'),
  ('Ms. Doreen Tumuheirwe', 'History Teacher', 'Social studies educator connecting past to present.');

INSERT INTO prefects (name, position) VALUES
  ('Alice Namukasa', 'Head Prefect'),
  ('Robert Tusiime', 'Deputy Head Prefect'),
  ('Patricia Akello', 'Academic Prefect'),
  ('Emmanuel Twesigye', 'Sports Prefect'),
  ('Sophia Asiimwe', 'Health Prefect'),
  ('Daniel Mugabe', 'Environment Prefect');

INSERT INTO announcements (title, content) VALUES
  ('First Term Examinations Schedule', 'The first term examinations will commence on the dates specified by the school administration. All students are required to prepare adequately.'),
  ('Sports Day Announcement', 'The annual sports day celebrations will be held at the school grounds. Parents and guardians are cordially invited to attend.'),
  ('School Fees Reminder', 'Parents and guardians are reminded to clear all outstanding school fees by the end of the first month of term.');

INSERT INTO articles (title, content, author, category, tags) VALUES
  ('The Importance of STEM Education in Uganda', 'Science, Technology, Engineering, and Mathematics (STEM) education plays a crucial role in the development of Uganda''s future workforce...', 'Mr. Peter Turyamureeba', 'Education', ARRAY['STEM', 'Science', 'Uganda', 'Education']),
  ('Study Tips for UCE Candidates', 'Preparing for the Uganda Certificate of Education (UCE) examinations requires dedication, smart study strategies, and proper time management...', 'Ms. Mary Nakato', 'Student Resources', ARRAY['UCE', 'Study Tips', 'Exams']),
  ('Building Leadership Skills in Secondary School', 'Leadership development is a fundamental aspect of secondary school education at St. Peter''s SS Rwera...', 'Ms. Grace Atuhaire', 'Leadership', ARRAY['Leadership', 'Character', 'Development']);
